import model.*;
import model.Character;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.swing.Timer;

import googleSheets.GoogleSheet;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
public class View extends Application{
	private StartPage startPage;
	private DmPage dmPage;
	//private DmCharacterSheetView dmCharacterSheetView;
	//private ClientCharacterSheetView clientCharacterSheetView;
	Scene scene;
	Stage primaryStage;
	FileChooser fileChooser;
	DMInGameView dmInGameView;
	ClientEditingView clientEditView;
	ClientInGameView clientInGameView;
	File file;
	GoogleSheet googleSheet;
	@Override
	public void start(Stage myPrimaryStage) throws Exception {
		primaryStage = myPrimaryStage;
		try{
			
			startPage = new StartPage(this);
			scene = new Scene(startPage, 600, 400);
			primaryStage.setScene(scene);
			primaryStage.show();
			fileChooser = new FileChooser();
			fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter(".ser", "*.ser"));
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	public void setWindowToStartPage(StartPage myStartPage){
		startPage = myStartPage;
		scene = new Scene(startPage, 600, 400);
		primaryStage.setScene(scene);
	}
	public void setWindowToDmPage(DmPage myDmPage){
		dmPage= myDmPage;
		scene = new Scene(dmPage, 600, 400);
		primaryStage.setScene(scene);
	}
	public void setWindowToDMCharacterSheetView(DMInGameView myDmInGameView){
		dmInGameView = myDmInGameView;
		scene = new Scene(dmInGameView, 800, 1000);
		primaryStage.setScene(scene);
	}
	public void setWindowToClientEditingView(ClientEditingView myClientEditView){
		clientEditView = myClientEditView;
		scene = new Scene(clientEditView, 800, 1000);
		primaryStage.setScene(scene);
	}
	public void setWindowToClientInGameView(ClientInGameView myClientInGameView){
		clientInGameView = myClientInGameView;
		scene = new Scene(clientInGameView, 800, 1000);
		primaryStage.setScene(scene);
	}
	public void newFileChooser(){
		file = fileChooser.showOpenDialog(primaryStage);
		
	}
	public File getFile(){
		return file;
	}
	public String getSaveLocation(){
		File myFile = fileChooser.showSaveDialog(primaryStage);
		return myFile.getAbsolutePath();
	}
	public CharacterSheet createNewCharacterSheet(Character myCharacter){
		
		CharacterSheet charactersheet = new CharacterSheet(primaryStage, myCharacter);
		return charactersheet;
	}
	public static void main(String[] args) {
		launch(args);
	}

	public GoogleSheet newGoogleSheet(String sheetId){
		try {
			googleSheet = new GoogleSheet(sheetId);
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		return googleSheet;
	}
	public GoogleSheet getSheet(){
		return googleSheet;
	}
	
}
