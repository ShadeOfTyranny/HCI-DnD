import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
public class View extends Application{
	private StartPage startPage;
	private DmPage dmPage;
	//private DmCharacterSheetView dmCharacterSheetView;
	//private ClientCharacterSheetView clientCharacterSheetView;
	Scene scene;
	Stage primaryStage;
	FileChooser fileChooser;
	DMInGameView dmInGameView;
	@Override
	public void start(Stage myPrimaryStage) throws Exception {
		primaryStage = myPrimaryStage;
		try{
			
			startPage = new StartPage(this);
			scene = new Scene(startPage, 600, 400);
			primaryStage.setScene(scene);
			primaryStage.show();
			fileChooser = new FileChooser();
			fileChooser.getExtensionFilters().add(
	                new FileChooser.ExtensionFilter("DnD Files", "*.dnd")
	            );
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	public void setWindowToStartPage(StartPage myStartPage){
		startPage = myStartPage;
		scene = new Scene(startPage, 600, 400);
		primaryStage.setScene(scene);
		
	}
	public void setWindowToDmPage(DmPage myDmPage){
		dmPage= myDmPage;
		scene = new Scene(dmPage, 600, 400);
		primaryStage.setScene(scene);
	}
	public void setWindowToDMCharacterSheetView(String googleLink){
		dmInGameView = new DMInGameView(googleLink, this);
		scene = new Scene(dmInGameView, 800, 1000);
		primaryStage.setScene(scene);
	}
	public void setWindowToClientCharacterSheetView(){
		
	}
	public void newFileChooser(){
		fileChooser.showOpenDialog(primaryStage);
	}
	public FileChooser getFileChooser(){
		return fileChooser;
	}
	public static void main(String[] args) {
		launch(args);
	}
	
}
