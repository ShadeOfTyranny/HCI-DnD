
public class GenerateKeys {
	public static String generateKey(String identifier, String googleURL){
		//https://docs.google.com/spreadsheets/d/17ZDZr4OjRN0XrtV90mInS_hI_d66gdqeWlM3p_hcy7w/edit#gid=0
		System.out.println(googleURL);
		int beginIndex = googleURL.indexOf("/d/")+3;
		int endIndex = beginIndex + 44;
		String spreadSheetId = googleURL.substring(beginIndex,endIndex);
		return identifier + spreadSheetId;
	}
}
