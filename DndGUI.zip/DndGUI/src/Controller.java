import java.io.IOException;

import googleSheets.GoogleSheet;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import model.*;
import model.Character;
public class Controller {
	public static void dMEnterButtonListener(Button DMEnterButton,View view){
		DMEnterButton.setOnMouseClicked(new EventHandler<MouseEvent>(){

			@Override
			public void handle(MouseEvent event) {
				view.setWindowToDmPage(new DmPage(view));
				
			}
			
		});
	}
	public static void goBackToStartPageListener(Button backButton, View view){
		backButton.setOnMouseClicked(new EventHandler<MouseEvent>(){

			@Override
			public void handle(MouseEvent event) {
				view.setWindowToStartPage(new StartPage(view));
				
			}
			
		});
	}
	public static void loadCharacterSheetListener(Button loadButton, View view){
		loadButton.setOnMouseClicked(new EventHandler<MouseEvent>(){

			@Override
			public void handle(MouseEvent event) {
				view.newFileChooser();
				ReadObject obj = new ReadObject();
				
				Character character = obj.deserialzeAddress(view.getFile().getAbsolutePath());
				
				ClientEditingView myClientEditView = new ClientEditingView(view,character);
				
				view.setWindowToClientEditingView(myClientEditView);
				//sheet.setCharacter
				
			}
			
		});
	}
	public static void saveLocallyListener(Button saveLocally,Character character, View view){
		saveLocally.setOnMouseClicked(new EventHandler<MouseEvent>(){

			@Override
			public void handle(MouseEvent event) {
				WriteObject obj = new WriteObject();
				obj.serializeAddress(new Character(character),view.getSaveLocation());
				
			}
			
		});
	}
	public static void createCharacterSheetListener(Button createButton, View view){
		createButton.setOnMouseClicked(new EventHandler<MouseEvent>(){

			@Override
			public void handle(MouseEvent event) {
				
				ClientEditingView myClientEditView = new ClientEditingView(view);
				
				view.setWindowToClientEditingView(myClientEditView);
				//sheet.setCharacter
				
			}
			
		});
	}
	public static void dMGoButtonListener(Button goButton, View view, TextField code){
		goButton.setOnMouseClicked(new EventHandler<MouseEvent>(){

			@Override
			public void handle(MouseEvent event) {
				try {
					DMInGameView dmInGameView = new DMInGameView(
							view, 
							code.getText());
					view.setWindowToDMCharacterSheetView(dmInGameView);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
			}
			
		});
	}
	public static void clientGoButtonListener(Button goButton, View view, TextField code){
		goButton.setOnMouseClicked(new EventHandler<MouseEvent>(){

			@Override
			public void handle(MouseEvent event) {
				try {
					ClientInGameView clientInGameView = new ClientInGameView(view, code.getText());
					view.setWindowToClientInGameView(clientInGameView);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
			}
			
		});
	}
	public static void pushToSheetsListener(Button pushButton, View view, Character character, TextField characterCode){
		pushButton.setOnMouseClicked(new EventHandler<MouseEvent>(){

			@Override
			public void handle(MouseEvent event) {
				if(characterCode.getText()!=null&&characterCode.getText()!=""&&!characterCode.getText().contains(" ")){
					char campaign = characterCode.getText().charAt(0);
					int characterNum = Integer.parseInt(characterCode.getText().substring(1, 2));
					if(view.getSheet()==null){
						view.newGoogleSheet(characterCode.getText().substring(2));
					}
					GoogleSheet sheet = view.getSheet();
					try {
						sheet.setCharacter(campaign, characterNum, ReadObject.toString(new Character(character)));
						
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
			}
			
		});
	}
	public static void pullFromSheetsListener(Button pullButton, View view, CharacterSheet sheet,TextField characterCode){
		pullButton.setOnMouseClicked(new EventHandler<MouseEvent>(){
			@Override
			public void handle(MouseEvent event) {
				char campaignChar = characterCode.getText().charAt(0);
				int characterNum = Integer.parseInt(characterCode.getText().substring(1, 2));
				GoogleSheet googleSheet = view.getSheet();
				Character tempChar;
				try {
					tempChar = ReadObject.fromString(googleSheet.getCharacterInfo(campaignChar, characterNum));
					sheet.setCharacterAfterPull(tempChar,true);
				} catch (ClassNotFoundException | IOException e) {
					e.printStackTrace();
				}
				
				
				
			}
		});
	}
	
	public static void copyToClipBoardListener(Button copyToClipBoard, String myStr){
		copyToClipBoard.setOnMouseClicked(new EventHandler<MouseEvent>(){

			@Override
			public void handle(MouseEvent event) {
				final Clipboard clipboard = Clipboard.getSystemClipboard();
			    final ClipboardContent content = new ClipboardContent();
			    content.putString(myStr);
			    clipboard.setContent(content);
				
			}
			
		});
	}
}
