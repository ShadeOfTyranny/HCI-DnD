import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class Controller {
	public static void dMEnterButtonListener(Button DMEnterButton,View view){
		DMEnterButton.setOnMouseClicked(new EventHandler<MouseEvent>(){

			@Override
			public void handle(MouseEvent event) {
				view.setWindowToDmPage(new DmPage(view));
				
			}
			
		});
	}
	public static void goBackToStartPageListener(Button backButton, View view){
		backButton.setOnMouseClicked(new EventHandler<MouseEvent>(){

			@Override
			public void handle(MouseEvent event) {
				view.setWindowToStartPage(new StartPage(view));
				
			}
			
		});
	}
	public static void loadCharacterSheetListener(Button loadButton, View view){
		loadButton.setOnMouseClicked(new EventHandler<MouseEvent>(){

			@Override
			public void handle(MouseEvent event) {
				view.newFileChooser();
				
			}
			
		});
	}
	public static void dMGoButtonListener(Button goButton, View view, String googleLink){
		goButton.setOnMouseClicked(new EventHandler<MouseEvent>(){

			@Override
			public void handle(MouseEvent event) {
				view.setWindowToDMCharacterSheetView(googleLink);
				
			}
			
		});
	}
	public static void copyToClipBoardListener(Button copyToClipBoard, String myStr){
		copyToClipBoard.setOnMouseClicked(new EventHandler<MouseEvent>(){

			@Override
			public void handle(MouseEvent event) {
				final Clipboard clipboard = Clipboard.getSystemClipboard();
			    final ClipboardContent content = new ClipboardContent();
			    content.putString(myStr);
			    clipboard.setContent(content);
				
			}
			
		});
	}
}
