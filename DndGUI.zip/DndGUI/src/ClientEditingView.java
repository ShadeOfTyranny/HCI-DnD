import model.Character;
import model.ReadObject;
import model.WriteObject;

import java.io.IOException;

import googleSheets.GoogleSheet;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;

public class ClientEditingView extends BorderPane{
	Button backButton;
	Button saveLocally;
	Button pushToCampaign;
	TextField characterCode;
	View view;
	Character character;
	ClientEditingView(View myView){
		character = new Character();
		view = myView;
		setUp();
	}
	ClientEditingView(View myView, Character myCharacter){
		character = myCharacter;
		view = myView;
		setUp();
	}
	private void setUp(){
		HBox hbox = new HBox();
		hbox.setPadding(new Insets(10,10,10,10));
		saveLocally = new Button("Save Locally");
		pushToCampaign = new Button("Push to Campaign");
		characterCode = new TextField("Insert character code here");
		backButton = new Button("Back");		
		
		Controller.goBackToStartPageListener(backButton, view);
		Controller.saveLocallyListener(saveLocally,character, view);
		
		try {
			Controller.pushToSheetsListener(pushToCampaign, view, character,characterCode);
			
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		hbox.getChildren().add(backButton);
		hbox.getChildren().add(saveLocally);
		hbox.getChildren().add(pushToCampaign);
		hbox.getChildren().add(characterCode);
		
		this.setTop(hbox);
		
		CharacterSheet sheet = view.createNewCharacterSheet(character);
		//sheet.setCharacter(character);
		sheet.setVisible(true);
		this.setCenter(sheet);
	}
}
