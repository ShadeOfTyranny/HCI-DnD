package googleSheets;
import java.io.IOException;

public class Driver {

	public static void main(String[] args) throws IOException {
		// https://docs.google.com/spreadsheets/d/17ZDZr4OjRN0XrtV90mInS_hI_d66gdqeWlM3p_hcy7w/edit?usp=sharing
		String spreadSheetId = "17ZDZr4OjRN0XrtV90mInS_hI_d66gdqeWlM3p_hcy7w";
		
		GoogleSheet sheet = new GoogleSheet(spreadSheetId);
		char campaign = 'A';
		
		String characterInfo = sheet.getCharacterInfo(campaign,1);
		System.out.println(characterInfo);
		sheet.setCharacter(campaign, 2, "oiwejfoijoiejoijefoijweoiejf");
		//sheet.setCharacterInfo('C', characters);
	}

}
