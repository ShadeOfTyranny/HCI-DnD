import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class StartPage extends GridPane{
	
	Button clientGoButton;
	TextField clientConnectField;
	Button createButton;
	Button loadButton;
	Button DMGoButton;
	Button DMEnterButton;
	
	StartPage(View view){
		this.setHgap(10);
	    this.setVgap(10);
	    this.setPadding(new Insets(0, 10, 0, 10));
	    
		
		
		clientGoButton = new Button("Go");
		
		Label clientLabel = new Label("Player");
		clientLabel.setUnderline(true);
		
		Label connect = new Label("Connect to a campaign?");
		
		clientConnectField = new TextField("Insert client ID");
		
		Label createOrEdit = new Label("Or work with a character locally");
		
		createButton = new Button("create");
		loadButton = new Button("load");
		HBox buttonBox = new HBox();
		buttonBox.setSpacing(10);
		buttonBox.getChildren().add(createButton);
		buttonBox.getChildren().add(loadButton);
		
		this.add(clientLabel,0,0);
		this.add(connect,0,1);
		this.add(clientConnectField, 0, 2);
		this.add(clientGoButton,1,2);
		this.add(createOrEdit, 0, 3);
		this.add(buttonBox, 0, 4);
		
		DMGoButton = new Button("Go");
		
		Label DMLabel = new Label("Dungeon Master");
		DMLabel.setUnderline(true);
		
		Label DMConnect = new Label("DM's can enter or create a campaign");
		
		DMEnterButton = new Button("View DM page");
		
		this.add(DMLabel,4,0);
		this.add(DMConnect,4,1);
		//this.add(DMConnectField, 4, 2);
		//this.add(DMGoButton,5,2);
		//this.add(createDM, 4, 3);
		this.add(DMEnterButton, 4, 2);
		
		Controller.dMEnterButtonListener(DMEnterButton,view);
		Controller.loadCharacterSheetListener(loadButton, view);
		
		
		
		
	}
	public Button getClientGoButton() {
		return clientGoButton;
	}
	public TextField getClientConnectField() {
		return clientConnectField;
	}
	public Button getCreateButton() {
		return createButton;
	}
	public Button getLoadButton() {
		return loadButton;
	}
	public Button getDMGoButton() {
		return DMGoButton;
	}
	public Button getDMEnterButton() {
		return DMEnterButton;
	}
}
