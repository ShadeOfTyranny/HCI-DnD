import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.Timer;

import googleSheets.GoogleSheet;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.util.Duration;
import model.ReadObject;
import model.Character;

public class ClientInGameView extends BorderPane{
	Character myCharacter=null;
	GoogleSheet googleSheet;
	CharacterSheet sheet;
	int characterNum;
	char campaignChar;
	ClientInGameView(View view, String code) throws IOException {
		String spreadSheetId = code.substring(2);
		
		System.out.println(code);
		System.out.println(spreadSheetId);
		
		this.setPadding(new Insets(10, 10, 10, 10));
		Button backButton = new Button("Back");
		
		this.setTop(backButton);
		Controller.goBackToStartPageListener(backButton, view);
		TabPane masterTabPane = new TabPane();
		this.setCenter(masterTabPane);
		

		googleSheet = view.newGoogleSheet(spreadSheetId);
		campaignChar = code.charAt(0);
		characterNum = Integer.parseInt(code.substring(1,2));
		
		String campaignName = googleSheet.getCharacterInfo(campaignChar, 0);
		String characterSer = googleSheet.getCharacterInfo(campaignChar, characterNum);
		
		
		//campaignInfo = googleSheet.getCampaignInfo(campaignChar);
		
		TabPane tabPane = new TabPane();
		Tab masterTab = new Tab();
		masterTab.setContent(tabPane);
		masterTab.setText(campaignName);
		masterTab.setClosable(false);
		
		Label playerCodeLabel = new Label("Character code  ");
		
		TextField playerCode = new TextField(code);
		
		Button copyToClipBoard = new Button("Copy to clipboard");
		//Button pullButton = new Button("Pull from Sheets");
		
		Controller.copyToClipBoardListener(copyToClipBoard, playerCode.getText());
		
		HBox hBox = new HBox();
		hBox.setPadding(new Insets(10, 10, 10, 10));
		hBox.getChildren().add(playerCodeLabel);
		hBox.getChildren().add(playerCode);
		hBox.getChildren().add(copyToClipBoard);
		//hBox.getChildren().add(pullButton);
		
		
		playerCode.setEditable(false);
		BorderPane characterBorderPane = new BorderPane();
		characterBorderPane.setPadding(new Insets(10, 10, 10, 10));
		characterBorderPane.setTop(hBox);
		
		try {
			myCharacter = ReadObject.fromString(characterSer);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		sheet = view.createNewCharacterSheet(myCharacter);
		sheet.setGoogleSheet(googleSheet, campaignChar, characterNum);
		
		//Controller.pullFromSheetsListener(pullButton, view, sheet, playerCode);
		
		Timeline timeline = new Timeline(new KeyFrame(
		        Duration.millis(5000),
		        ae -> makePull()));
		timeline.setCycleCount(Animation.INDEFINITE);
		timeline.play();
		sheet.setVisible(true);
		characterBorderPane.setCenter(sheet);
		this.setCenter(characterBorderPane);
	}
	private void makePull(){
		try {
			if(System.currentTimeMillis()-sheet.getPushTime()>5000){
				Character tempChar = ReadObject.fromString(googleSheet.getCharacterInfo(campaignChar, characterNum));
				
				sheet.setCharacterAfterPull(tempChar,true);
			}
			
			
		} catch (IOException e1) {
			e1.printStackTrace();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
}
