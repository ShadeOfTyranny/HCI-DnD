

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextField;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;

public class DMInGameView extends BorderPane{
	DMInGameView(String googleLink, View view){
		this.setPadding(new Insets(10, 10, 10, 10));
		Button backButton = new Button("Back");
		this.setTop(backButton);
		Controller.dMEnterButtonListener(backButton, view);
		TabPane masterTabPane = new TabPane();
		this.setCenter(masterTabPane);
		
		for(int i=0;i<2; i++){
			
			TabPane tabPane = new TabPane();
			Tab masterTab = new Tab();
			masterTab.setContent(tabPane);
			masterTab.setText("Campaign "+(i+1));
			masterTab.setClosable(false);
			masterTabPane.getTabs().add(masterTab);
			
			for(int j = 0; j< 4-i; j++){
				Tab tab = new Tab();
				tab.setClosable(false);
				tab.setText("Character "+(j+1));
				Label playerCodeLabel = new Label("Give this code to the player  ");
				TextField playerCode = new TextField("weofijowiejfoihqoi3fhoj3oifj3o3i");
				Button copyToClipBoard = new Button("Copy to clipboard");
				Controller.copyToClipBoardListener(copyToClipBoard, playerCode.getText());
				HBox hBox = new HBox();
				hBox.setPadding(new Insets(10, 10, 10, 10));
				hBox.getChildren().add(playerCodeLabel);
				hBox.getChildren().add(playerCode);
				hBox.getChildren().add(copyToClipBoard);
				
				
				
				playerCode.setEditable(false);
				BorderPane characterBorderPane = new BorderPane();
				characterBorderPane.setPadding(new Insets(10, 10, 10, 10));
				characterBorderPane.setTop(hBox);
				tab.setContent(characterBorderPane);
				//tab.setContent(new Label(googleLink));
				tabPane.getTabs().add(tab);
			}
		}
	}
}
