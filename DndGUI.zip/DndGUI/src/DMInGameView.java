

import java.io.IOException;

import googleSheets.GoogleSheet;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.geometry.Insets;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextField;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.util.Duration;
import model.*;
import model.Character;
public class DMInGameView extends BorderPane {
	CharacterSheet sheet;
	GoogleSheet googleSheet;
	char campaignChar;
	int characterNum;
	DMInGameView(View view, String googleURL) throws IOException{
		
		this.setPadding(new Insets(10, 10, 10, 10));
		Button backButton = new Button("Back");
		this.setTop(backButton);
		Controller.dMEnterButtonListener(backButton, view);
		TabPane masterTabPane = new TabPane();
		this.setCenter(masterTabPane);
		
		int i = 65;
		String code = GenerateKeys.generateKey("", googleURL);
		googleSheet = new GoogleSheet(code);
		campaignChar = (char)i;
		String campaignName = googleSheet.getCharacterInfo(campaignChar, 0);
		
		
		while(googleSheet.getCharacterInfo(campaignChar, 0)!=null){
		
			campaignName = googleSheet.getCharacterInfo(campaignChar, 0);
			
			TabPane tabPane = new TabPane();
			Tab masterTab = new Tab();
			masterTab.setContent(tabPane);
			masterTab.setText(campaignName);
			masterTab.setClosable(false);
			masterTabPane.getTabs().add(masterTab);
			int j = 1;
			String characterSer = googleSheet.getCharacterInfo(campaignChar, j);
			
			while(characterSer!=null){
				characterNum = j;
				
//				Tab tab = new Tab();
//				tab.setClosable(false);
//				tab.setText("Character "+(j+1));
//				Label playerCodeLabel = new Label("Give this code to the player  ");
//				TextField playerCode = new TextField(campaignChar+String.valueOf(j)+code);
//				
//				Button copyToClipBoard = new Button("Copy to clipboard");
//				Controller.copyToClipBoardListener(copyToClipBoard, playerCode.getText());
//				HBox hBox = new HBox();
//				hBox.setPadding(new Insets(10, 10, 10, 10));
//				hBox.getChildren().add(playerCodeLabel);
//				hBox.getChildren().add(playerCode);
//				hBox.getChildren().add(copyToClipBoard);
//				
//				playerCode.setEditable(false);
//				BorderPane characterBorderPane = new BorderPane();
//				characterBorderPane.setPadding(new Insets(10, 10, 10, 10));
//				characterBorderPane.setTop(hBox);
//				
//				Character character=null;
//				try {
//					character = ReadObject.fromString(characterSer);
//				} catch (ClassNotFoundException e) {
//					e.printStackTrace();
//				}
//				sheet = view.createNewCharacterSheet(character);
//				
//				sheet.setVisible(true);
//				characterBorderPane.setCenter(sheet);
//				tab.setContent(characterBorderPane);
//				tabPane.getTabs().add(tab);
//				
//				sheet.setGoogleSheet(googleSheet, campaignChar, j);
//			
//				
//				Timeline timeline = new Timeline(new KeyFrame(
//				        Duration.millis(10000),
//				        ae -> makePull()));
//				timeline.setCycleCount(Animation.INDEFINITE);
//				
//				timeline.play();
//				sheet.setVisible(true);
//				characterBorderPane.setCenter(sheet);
//				this.setCenter(characterBorderPane);
//				//re-initialize characterser
				
				ClientInGameView clientView = new ClientInGameView(view, "A117ZDZr4OjRN0XrtV90mInS_hI_d66gdqeWlM3p_hcy7w");
				Tab tab = new Tab();
				tab.setClosable(false);
				tab.setText("Character "+j);
				tab.setContent(clientView);
				tabPane.getTabs().add(tab);
				characterSer = googleSheet.getCharacterInfo(campaignChar, j);
				j++;
			}
			
			i++;
			campaignChar = (char)i;
			
	
		}
		
			
	}
//	private void makePull(){
//		try {
//			if(System.currentTimeMillis()-sheet.getPushTime()>5000){
//				Character tempChar = ReadObject.fromString(googleSheet.getCharacterInfo(campaignChar, characterNum));
//				
//				sheet.setCharacterAfterPull(tempChar,true);
//			}
//			
//			
//		} catch (IOException e1) {
//			e1.printStackTrace();
//		} catch (ClassNotFoundException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
//	}
}
