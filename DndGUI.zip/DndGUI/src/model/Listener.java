package model;

public interface Listener {
	
	void updated();

}
