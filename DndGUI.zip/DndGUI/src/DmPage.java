import java.io.IOException;

import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import model.*;
public class DmPage extends BorderPane{
	Button backButton;
	DmPage(View view){
		//BorderPane borderPane = new BorderPane();
		GridPane createCampaignPane = new GridPane();
		
		createCampaignPane.setHgap(10);
		createCampaignPane.setVgap(10);
		createCampaignPane.setPadding(new Insets(0, 3, 0, 2));
		this.setCenter(createCampaignPane);
		this.setPadding(new Insets(10, 10, 10, 10));
		
		Label newDMLabel = new Label("New DM");
		newDMLabel.setUnderline(true);
		
		Label step1 = new Label("Step 1: Make a new google spreadsheet");
		Label step2 = new Label("Step 2: Click the share button in the top right corner \n "
								+ "\t\tSelect 'Anyone with the link can edit'");
		Label step3 = new Label("Step 3: Copy the link and insert it into the text box below ");
		//17ZDZr4OjRN0XrtV90mInS_hI_d66gdqeWlM3p_hcy7w
		TextField googleSpreadSheetURL = new TextField("https://docs.google.com/spreadsheets/d/17ZDZr4OjRN0XrtV90mInS_hI_d66gdqeWlM3p_hcy7w/edit#gid=0");
		Button goButton = new Button("Go");
		backButton = new Button("Go Back");
		this.setTop(backButton);
		
		Label returningDMLabel = new Label("Returning DM");
		returningDMLabel.setUnderline(true);
		Label retLinkLabel = new Label("Insert sheets link below");
		Controller.goBackToStartPageListener(backButton, view);
		

		Controller.dMGoButtonListener(goButton, view, googleSpreadSheetURL);

		
		
		createCampaignPane.add(newDMLabel, 0, 1);
		createCampaignPane.add(step1, 0, 2);
		createCampaignPane.add(step2, 0, 3);
		createCampaignPane.add(step3, 0, 4);
		createCampaignPane.add(retLinkLabel, 0, 7);
		createCampaignPane.add(googleSpreadSheetURL, 0, 8);
		createCampaignPane.add(goButton, 1, 8);
		createCampaignPane.add(returningDMLabel, 0, 6);
		
		
	}
}
